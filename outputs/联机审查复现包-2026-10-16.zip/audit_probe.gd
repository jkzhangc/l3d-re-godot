extends SceneTree

const ROOT := "D:/!bird's-eye-view-arpg-test-/l3d-re-godot"
var results: Array = []
var checks := 0
var failed := 0

func check(label: String, ok: bool, data: Dictionary = {}) -> void:
	checks += 1
	if not ok:
		failed += 1
	results.append({"label": label, "passed": ok, "data": data})
	print("AUDIT ", "PASS " if ok else "FAIL ", label, " ", JSON.stringify(data))

func _initialize() -> void:
	call_deferred("run")

func run() -> void:
	var source := FileAccess.get_file_as_string("res://network_snapshot_interp_snapshot.gd")
	var script := GDScript.new()
	# Inject only a deterministic clock into a memory copy. No production file is changed.
	script.source_code = source.replace("return float(Time.get_ticks_msec()) / 1000.0", "return float(get_meta(\"audit_now\", 0.0))")
	var error := script.reload()
	check("production_interp_loaded_with_clock_only_injection", error == OK, {"source_sha256": source.sha256_text()})
	if error != OK:
		quit(1)
		return
	var interp: RefCounted = script.new(0.021, 0.060, true)
	interp.set_meta("audit_now", 1.0)
	interp.call("reset", Vector2.ZERO)
	interp.call("push_sample", Vector2(4.0, 0.0))
	interp.set_meta("audit_now", 1.100)
	var extrapolated: Vector2 = interp.call("sample_render_position")
	check("same_timestamp_enemy_extrapolation_exceeds_600px", extrapolated.x > 600.0, {"sample_delta_px": 4.0, "sample_gap_ms": 0, "result_x_px": extrapolated.x, "overshoot_px": extrapolated.x - 4.0})
	var player: RefCounted = script.new(0.022, 0.055, false)
	player.set_meta("audit_now", 1.0)
	player.call("reset", Vector2.ZERO)
	player.call("push_sample", Vector2(4.0, 0.0))
	player.set_meta("audit_now", 1.100)
	var held: Vector2 = player.call("sample_render_position")
	check("remote_player_extrapolation_disabled_control", is_equal_approx(held.x, 4.0), {"result_x_px": held.x})
	var burst: RefCounted = script.new(0.022, 0.055, false)
	burst.set_meta("audit_now", 9.9)
	burst.call("reset", Vector2.ZERO)
	for i: int in range(1, 7):
		burst.set_meta("audit_now", 9.9 + float(i) / 60.0)
		burst.call("push_sample", Vector2(float(i) * 250.0 / 60.0, 0.0))
	for i: int in range(12):
		burst.call("push_sample", Vector2(25.0, 0.0))
	var before: Vector2 = burst.call("sample_render_position")
	var delay_before: float = burst.call("render_delay")
	burst.set_meta("audit_now", 10.005)
	burst.call("push_sample", Vector2(26.25, 0.0))
	var after: Vector2 = burst.call("sample_render_position")
	check("adaptive_buffer_can_reverse_monotonic_motion_after_burst", after.x < before.x, {"before_x": before.x, "after_x": after.x, "reverse_px": before.x - after.x, "delay_before_ms": delay_before * 1000.0, "delay_after_ms": float(burst.call("render_delay")) * 1000.0})
	var stale: RefCounted = script.new(0.022, 0.055, false)
	stale.set_meta("audit_now", 1.0)
	stale.call("reset", Vector2(100.0, 0.0))
	stale.set_meta("audit_now", 1.017)
	stale.call("push_sample", Vector2(104.0, 0.0))
	stale.set_meta("audit_now", 1.033)
	stale.call("push_sample", Vector2(80.0, 0.0))
	stale.set_meta("audit_now", 1.200)
	var old_position: Vector2 = stale.call("sample_render_position")
	check("interpolator_treats_late_old_position_as_new_sample", is_equal_approx(old_position.x, 80.0), {"latest_dynamic_x": 104, "late_stale_x": 80, "result_x": old_position.x, "scope": "interpolator only; RPC freshness absence verified by source"})
	var base_row: Array = [2, "Player", "res://object/character_nobita.tres", 100.0, Vector2(100, 100), 0, true, false, "pistol_01", "pistol_01", "knife_01", "primary", {"pistol_01": 12}, false, "", "", false, false, 3, false, 12, false, -1.0, 0.0, false, -1, {"pistol_ammo": 50}, "", 0]
	var sizes: Array = []
	for n: int in range(1, 5):
		var players: Array = []
		for i: int in range(n):
			var row: Array = base_row.duplicate(true)
			row[0] = i + 1
			players.append(row)
		sizes.append({"players": n, "variant_array_bytes": var_to_bytes(players).size(), "scope": "Variant serialization, not RPC/ENet wire size"})
	check("player_variant_serialization_measured", base_row.size() == 29, {"row_fields": base_row.size(), "sizes": sizes})
	var enemy := [1, Vector2(100, 100), 0, 100.0, true, 0, false, false, 0]
	var enemy_rows: Array = []
	for i: int in range(12):
		enemy_rows.append(enemy.duplicate())
	check("enemy_variant_chunk_serialization_measured", true, {"one_entry_bytes": var_to_bytes(enemy).size(), "array_12_bytes": var_to_bytes(enemy_rows).size(), "rpc_args_array_bytes": var_to_bytes([[], enemy_rows]).size(), "scope": "Variant serialization, not RPC/ENet wire size"})
	var output := FileAccess.open("res://probe_results.json", FileAccess.WRITE)
	output.store_string(JSON.stringify({"engine": Engine.get_version_info(), "checks": checks, "failed": failed, "results": results}, "\t"))
	output.close()
	print("AUDIT_SUMMARY checks=", checks, " failed=", failed)
	quit(1 if failed else 0)
