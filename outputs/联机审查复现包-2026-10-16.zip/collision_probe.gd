extends SceneTree

func _initialize() -> void:
	call_deferred("run")

func add_body(world: Node2D, position: Vector2, size: Vector2, layer: int, mask: int, disabled: bool = false) -> CharacterBody2D:
	var body := CharacterBody2D.new()
	body.position = position
	body.collision_layer = layer
	body.collision_mask = mask
	var shape := CollisionShape2D.new()
	var rect := RectangleShape2D.new()
	rect.size = size
	shape.shape = rect
	shape.disabled = disabled
	body.add_child(shape)
	world.add_child(body)
	return body

func run() -> void:
	var world := Node2D.new()
	root.add_child(world)
	# Match production player/enemy body layers and box sizes, with stationary enemy.
	var host_player := add_body(world, Vector2(0, 0), Vector2(24, 27), 4, 11)
	var host_enemy := add_body(world, Vector2(100, 0), Vector2(20, 28), 8, 15)
	var client_player := add_body(world, Vector2(0, 200), Vector2(24, 27), 4, 11)
	var client_enemy := add_body(world, Vector2(100, 200), Vector2(20, 28), 8, 15, true)
	await physics_frame
	await process_frame
	var host_hit := host_player.move_and_collide(Vector2(150, 0))
	var client_hit := client_player.move_and_collide(Vector2(150, 0))
	var result := {"host_final_x": host_player.position.x, "client_final_x": client_player.position.x, "divergence_px": client_player.position.x - host_player.position.x, "host_collided": host_hit != null, "client_collided": client_hit != null, "scope": "Minimal Godot physics reproduction with production layer/mask/box dimensions; client enemy shape disabled as in enemy._disable_network_simulation; not full gameplay"}
	print("AUDIT_COLLISION ", JSON.stringify(result))
	var output := FileAccess.open("res://collision_results.json", FileAccess.WRITE)
	output.store_string(JSON.stringify(result, "\t"))
	output.close()
	quit(0 if host_hit != null and client_hit == null else 1)
