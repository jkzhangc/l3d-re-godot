extends SceneTree

class RpcWorld extends Node:
	var received := 0
	var seen: Array = []
	@rpc("authority", "call_remote", "unreliable_ordered")
	func player_position_snapshot(states: Array) -> void:
		received += 1
		seen.append("player")
	@rpc("authority", "call_remote", "unreliable_ordered")
	func player_snapshot(players: Array, enemies: Array) -> void:
		seen.append("enemy")

var host_peer: ENetMultiplayerPeer
var client_peer: ENetMultiplayerPeer
var host_api: SceneMultiplayer
var client_api: SceneMultiplayer
var host_world: RpcWorld
var client_world: RpcWorld
var downstream := PacketPeerUDP.new()
var upstream := PacketPeerUDP.new()
var capture := false
var captured: Array = []
var measurements: Array = []

func _initialize() -> void:
	call_deferred("run")

func frame() -> void:
	host_api.poll()
	client_api.poll()
	while downstream.get_available_packet_count() > 0:
		var packet := downstream.get_packet()
		upstream.put_packet(packet)
	while upstream.get_available_packet_count() > 0:
		var packet := upstream.get_packet()
		if capture:
			captured.append(packet.size())
		downstream.set_dest_address("127.0.0.1", client_peer.get_host().get_local_port())
		downstream.put_packet(packet)
	await process_frame

func run() -> void:
	multiplayer_poll = false
	host_peer = ENetMultiplayerPeer.new()
	host_peer.set_bind_ip("127.0.0.1")
	var error := host_peer.create_server(0, 1)
	if error != OK:
		printerr("AUDIT_RPC_SETUP_FAIL host ", error)
		quit(1)
		return
	downstream.bind(0, "127.0.0.1")
	upstream.bind(0, "127.0.0.1")
	upstream.connect_to_host("127.0.0.1", host_peer.get_host().get_local_port())
	client_peer = ENetMultiplayerPeer.new()
	client_peer.create_client("127.0.0.1", downstream.get_local_port())
	host_api = SceneMultiplayer.new()
	client_api = SceneMultiplayer.new()
	host_api.multiplayer_peer = host_peer
	client_api.multiplayer_peer = client_peer
	var host_root := Node.new()
	host_root.name = "HostSide"
	var client_root := Node.new()
	client_root.name = "ClientSide"
	set_multiplayer(host_api, NodePath("/root/HostSide"))
	set_multiplayer(client_api, NodePath("/root/ClientSide"))
	root.add_child(host_root)
	root.add_child(client_root)
	host_world = RpcWorld.new()
	client_world = RpcWorld.new()
	host_world.name = "World"
	client_world.name = "World"
	host_root.add_child(host_world)
	client_root.add_child(client_world)
	var started := Time.get_ticks_msec()
	while client_peer.get_connection_status() != MultiplayerPeer.CONNECTION_CONNECTED or host_api.get_peers().is_empty():
		await frame()
		if Time.get_ticks_msec() - started > 5000:
			printerr("AUDIT_RPC_SETUP_FAIL connection_timeout")
			quit(1)
			return
	var target := int(client_api.get_unique_id())
	host_world.player_position_snapshot.rpc_id(target, [])
	started = Time.get_ticks_msec()
	while Time.get_ticks_msec() - started < 200:
		await frame()
	var base_row: Array = [2, "Player", "res://object/character_nobita.tres", 100.0, Vector2(100, 100), 0, true, false, "pistol_01", "pistol_01", "knife_01", "primary", {"pistol_01": 12}, false, "", "", false, false, 3, false, 12, false, -1.0, 0.0, false, -1, {"pistol_ammo": 50}, "", 0]
	for n: int in range(1, 5):
		var states: Array = []
		for i: int in range(n):
			var row: Array = base_row.duplicate(true)
			row[0] = i + 1
			states.append(row)
		captured.clear()
		capture = true
		var received_before := client_world.received
		host_world.player_position_snapshot.rpc_id(target, states)
		host_peer.get_host().flush()
		started = Time.get_ticks_msec()
		while Time.get_ticks_msec() - started < 100:
			await frame()
		capture = false
		var measurement := {"players": n, "row_fields": base_row.size(), "variant_bytes": var_to_bytes(states).size(), "host_to_client_udp_sizes": captured.duplicate(), "rpc_received": client_world.received - received_before}
		measurements.append(measurement)
		print("AUDIT_RPC ", JSON.stringify(measurement))
	# Warm up both RPC name/path caches before manually reversing two UDP datagrams.
	host_world.player_snapshot.rpc_id(target, [], [[1]])
	started = Time.get_ticks_msec()
	while Time.get_ticks_msec() - started < 100:
		await frame()
	client_world.seen.clear()
	host_world.player_position_snapshot.rpc_id(target, [[1]])
	host_peer.get_host().flush()
	host_api.poll()
	var reorder_deadline := Time.get_ticks_msec() + 3000
	while upstream.get_available_packet_count() == 0 and Time.get_ticks_msec() < reorder_deadline:
		await process_frame
	var first := upstream.get_packet()
	host_world.player_snapshot.rpc_id(target, [], [[2]])
	host_peer.get_host().flush()
	host_api.poll()
	while upstream.get_available_packet_count() == 0 and Time.get_ticks_msec() < reorder_deadline:
		await process_frame
	var second := upstream.get_packet()
	downstream.set_dest_address("127.0.0.1", client_peer.get_host().get_local_port())
	downstream.put_packet(second)
	await process_frame
	client_api.poll()
	downstream.put_packet(first)
	started = Time.get_ticks_msec()
	while Time.get_ticks_msec() - started < 100:
		await frame()
	var reorder := {"first_udp_bytes": first.size(), "second_udp_bytes": second.size(), "receive_order": client_world.seen.duplicate(), "scope": "Two actual ENet unreliable_ordered RPC datagrams delivered in reverse order; same default channel"}
	print("AUDIT_REORDER ", JSON.stringify(reorder))
	var output := FileAccess.open("res://rpc_size_results.json", FileAccess.WRITE)
	output.store_string(JSON.stringify({"engine": Engine.get_version_info(), "scope": "Real local ENet RPC with production-shaped 29-field synthetic player rows; not production gameplay capture", "measurements": measurements, "reorder": reorder}, "\t"))
	output.close()
	client_peer.close()
	host_peer.close()
	downstream.close()
	upstream.close()
	quit(0)
